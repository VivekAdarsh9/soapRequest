package com.soaprequest;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
/**
 * Hello world!
 */
public final class App {
    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");

        File xmlFile = new File("C:\\Users\\Shubhama3\\OneDrive - Verifone\\Desktop\\vivek\\soaprequest\\src\\input\\soapRequest.xml");
        Reader fileReader = new FileReader(xmlFile);
        BufferedReader bufReader = new BufferedReader(fileReader);
        
        StringBuilder sb = new StringBuilder();
        String line = bufReader.readLine();
        while( line != null){
            sb.append(line).append("\n");
            line = bufReader.readLine();
        }
        String xml2String = sb.toString();
        InputStream inputxml = new ByteArrayInputStream(xml2String.getBytes());
        System.out.println(inputxml);
        callSoapWebService("https://sutherland.taleo.net/enterprise/soap?ServiceName=IntegrationManagementService", inputxml, "kovaion_team", "uT_8MdG1");
    }




    private static String callSoapWebService(String soapEndpointUrl, InputStream is, String username,
            String password) {
                System.out.println("Inside Method callSoapWebService");
        String returnvalue = "";
        try {
            System.out.println("userName"+username);
            System.out.println("password"+password);
            String userCredentials = username + ":" + password;
            String basicAuth = "Basic " + new String(new Base64().encode(userCredentials.getBytes()));
            System.out.println(basicAuth);
            try{
            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
            }catch(Exception e){
                System.out.println(e);
            }
           
           // SOAPConnection soapConnection = soapConnectionFactory.createConnection();
            System.out.println("Connection Created");

            SOAPMessage soapRequest = MessageFactory.newInstance().createMessage(null, is);
            System.out.println(soapRequest);
            MimeHeaders hd = soapRequest.getMimeHeaders();
                SOAPHeader header = soapRequest.getSOAPPart().getEnvelope().getHeader();
                SOAPHeaderElement actionElement = header.addHeaderElement(new QName("http://www.w3.org/2005/08/addressing", "Action"));
                actionElement.setMustUnderstand(true);
                header.addHeaderElement(new QName("http://www.w3.org/2005/08/addressing", "MessageID")).addTextNode("uuid:" + UUID.randomUUID().toString());
                // actionElement.addTextNode(action);
            hd.addHeader("Authorization", basicAuth);
           // SOAPMessage soapResponse = soapConnection.call(soapRequest, soapEndpointUrl);
          //  System.out.println("soapresponse"+soapResponse);
            /****** extract zip ****/

            
            /**** extract zip *****/

            /** write to a variable **/
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
           // soapResponse.writeTo(stream);
            returnvalue = new String(stream.toByteArray(), "utf-8");
        } catch (Exception e) {
            returnvalue = "Error occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!";
        }
        return returnvalue;
    }
}
